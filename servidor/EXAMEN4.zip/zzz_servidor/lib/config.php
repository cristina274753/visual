<?php



define('BASE_URL', '/php/zzz_servidor/public');


?>