
<?php

if (!defined('BD_HOST')) {


    define('BD_HOST', 'localhost'); 
    define('BD_NAME', 'monroy_delivery'); //nombre base de datos
    define('BD_USER', 'dwes25');   // usuario BD
    define('BD_PASS', 'dwes');  //contraseña del usuario


}



?>
