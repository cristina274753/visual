<?php
require_once "../lib/config.php";
//Autocargador de clases 
require_once "../vendor/autoload.php";

//cargador de rutas
require_once "../routes/web.php";


?>